---
id: AD-004
type: architecture-decision
title: Module Surfaces Follow Responsibilities
summary: "One module per responsibility; study, binding, compare, and fixture name the records they own."
date: 2026-10-23
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - src/pyssp_workflow/study
  - src/pyssp_workflow/binding.py
  - src/pyssp_workflow/compare.py
  - src/pyssp_workflow/fixture.py
supersedes: []
superseded_by: []
related: [AD-005]
---

# AD-004: Module Surfaces Follow Responsibilities

## Context

The first layout mirrored flow stages: `authoring`, `params`, `packaging`,
`execute`, `plan`, `report`, `cli`. Several modules were named empty
contracts. `packaging` imported `authoring.FixtureBuild` for a record that is
not a build step; `authoring` and `binding` needed it but neither owned it.
`params` re-read the study scenario the descriptor already named. `execute`
was a thin wrapper around measurement. `plan`, `report`, and `cli` were empty
stubs. `ComparisonRecord` carried `status`/`error` fields no producer filled.

## Decision

- Replaced the stage layout with one module per responsibility; deleted the empty `plan`, `report`, and `cli` stubs.
- `params` became `study`: `Experiment`, `StudyDescriptor`, `read_study_descriptor`, `Scenario`, `read_scenario`, `scenario_targets`.
- `packaging` became `binding`: the `Binding` union and `apply_bindings`.
- `execute` became `compare`: `ResultRef`, `ComparisonRequest`, `ComparisonRecord`, `compare_csvs`.
- `authoring.FixtureBuild` became `fixture.BuiltFixture`; `fixture` also owns `artifacts_root`, `study_dir`, `model_dir`.
- Removed `ComparisonRecord.status` and `.error`; consolidated duplicated helpers.

## Rationale

A module name should say what the module is, not which flow stage called it.
`study`, `binding`, `compare`, and `fixture` name the records and operations
they own, which makes the import graph acyclic: `fixture` imports only
`study`; `authoring` and `binding` both import `fixture` and `study`, so
neither depends on the other. Deleting empty stubs removed surfaces that
promised behaviour without implementing it.

## Alternatives Considered

- Keep the stage names and only delete the empty stubs. Rejected: the
  `packaging` dependency on `authoring.FixtureBuild` still points the wrong
  way.
- Keep `FixtureBuild` in `authoring`. Rejected: `binding` needs the record
  without needing a build.
- Keep `status`/`error` on `ComparisonRecord` for forward compatibility.
  Rejected: no producer set them.

## Consequences

- `authoring` still never imports `pyssp_vv`; only `nodes` may import
  `pyssp_vv.judge`.
- The `Binding` union was closed: a new shape meant a new record and a new
  branch in `apply_bindings`.
- `ComparisonRecord` stays plain data and round-trips without a verdict field.
- `BuiltFixture` is shared by `authoring` and `binding`; neither owns the
  other.
- `tests/test_layering.py` enforces the layering rules.

## Verification

`tests/test_layering.py` enforces the import rules.
`tests/test_compare.py::test_comparison_record_from_dict_ignores_legacy_status_and_error`
covers the removed fields.

## Review Trigger

A module responsibility that no existing module owns.
