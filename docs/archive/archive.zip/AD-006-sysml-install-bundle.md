---
id: AD-006
type: architecture-decision
title: SysML Install Bundle — Pin Without Import
summary: "pyssp_workflow carries the SysML/FMI siblings as an install-only extra and never imports them."
date: 2026-11-05
status: accepted
layers: [architecture, product, operation]
state: 01-product/distribution.md
artifacts:
  - pyproject.toml
  - requirements-sysml.txt
  - .gitmodules
supersedes: []
superseded_by: []
related: [AD-003, AD-004]
---

# AD-006: SysML Install Bundle — Pin Without Import

## Context

`authoring` derived SysML through the external `pyssp` CLI and imported no
SysML library. A SysML consumer still needed the matching set:
`pyssp_sysml2`, `pyfmi_sysml2`, and their shared `pycps_sysml2`. `INFO-001`
committed to composition only and `tests/test_layering.py` enforced it, so an
install convenience could not become a surface.

## Decision

- Added a `sysml` extra with two direct references only: `pyssp-sysml2`
  `v0.4.0` and `pyfmi-sysml2` `v0.1.0`.
- Left `pycps-sysml2` transitive: both siblings declare it, one owner per pin.
- Kept `build` CLI-only and made `all` `flow` plus `sysml`.
- Linked `pycps_sysml2` and `pyfmi_sysml2` at `v0.1.0`; added both to `requirements-sysml.txt`.
- Imported none of the three and left `tests/test_layering.py` unchanged.

## Rationale

The extra described what an install pulls in, not what the package exposed.
Three libraries that only work in combination belong on one pin list, so the
release wheel and the editable checkout resolve to the same revisions. Keeping
`pycps-sysml2` transitive avoided two owners asserting one version.

## Alternatives Considered

- Put the siblings in `build`. Rejected: `build` is the `pyssp` CLI alone.
- Add `pycps-sysml2` directly. Rejected: two owners for one pin.
- Import `pyfmi_sysml2` so the extra has a surface. Rejected: it breaks the
  composition-only intent for an install detail.
- Document the pins in prose only. Rejected: prose does not constrain install.

## Consequences

- Positive: `pip install "pyssp-workflow[sysml]"` yields the matching set.
- Positive: `INFO-001` and the layering rules stayed untouched.
- Negative: the nested gitlinks and the extra must move together on a bump.

## Verification

`tests/test_layering.py` is unchanged; `tests/test_distribution.py` asserts the
extra's two direct references.

## Review Trigger

A module needs to import one of the three, or a sibling stops declaring
`pycps-sysml2`.
