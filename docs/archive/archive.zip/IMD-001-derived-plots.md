---
id: IMD-001
type: implementation-decision
title: Figures Are Derived Artifacts
summary: "Figure specification lives in pyssp_vv; this package renders figures and never hashes them into evidence."
date: 2026-10-22
status: accepted
layers: [implementation, architecture]
state: 02-architecture/architecture.md
artifacts: []
supersedes: []
superseded_by: []
related: []
---

# IMD-001: Figures Are Derived Artifacts

## Context

Plotting was briefly treated as a reporting adapter to add after the pipeline worked. That inverted the development loop: during development the figure is the instrument used to decide whether a model bug, an engine difference, or an inappropriate tolerance is observed. A figure cannot be evidence: Matplotlib output is not stable across versions, fonts, and backends, and a picture is not a measurable claim.

## Decision

- The figure specification — overlay, residual panel, criterion band, gap shading, shift indicator — is defined in `pyssp_vv.measure.figures`, next to the measurements and the policy it displays.
- This package owns the rendering workflow: choosing signals for a view, owning the output directory, writing the plot manifest.
- Figures are never hashed into evidence; the plot manifest records input digests and the renderer version so a figure can be traced back.
- A comparison figure draws the criterion band on the same axes as the data.
- Plot signals are chosen independently of gate signals; neither inherits the other's list.

## Rationale

The development path needs a figure before a bundle exists, so rendering cannot wait for evidence. A figure cannot carry a reproducibility claim, while evidence can. Splitting the specification from the rendering workflow keeps Matplotlib behind an extra of `pyssp_vv` and keeps pixels out of evidence.

## Alternatives Considered

- Treat plotting as a reporting adapter added after the pipeline works. Rejected: it inverts the development loop.

## Consequences

- Figures can be rendered from a comparison, not only from an evidence bundle.
- Reproducibility claims apply to evidence, not to pixels.
- Matplotlib stays behind an extra of `pyssp_vv`, not a dependency of the workflow layer.

## Verification

None.

## Review Trigger

A figure format or renderer that makes figures reproducible across environments.
