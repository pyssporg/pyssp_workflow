---
id: AD-001
type: architecture-decision
title: Node-First Composition
summary: "Work units are plain functions; the optional node layer applies @node only at artifact boundaries."
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/node-catalog.md
artifacts:
  - src/pyssp_workflow/nodes/__init__.py
supersedes: []
superseded_by: []
related: []
---

# AD-001: Node-First Composition

## Context

The workflow layer had to run build, simulate, measure, and judge steps in
parallel with an audit trail. The orchestration engine was
`sequence_extensions`, whose unit of work is the `@node` function. Two shapes
were possible: make every workflow function a node, or keep plain functions
and wrap only the units that need scheduling policy.

## Decision

Adopted the second option.

- Plain functions in the workflow modules do the work.
- `pyssp_workflow.nodes` applies `@node` at artifact boundaries.
- Node inputs and outputs are paths and plain data, so they survive a process
  pool.
- The capability itself lives in `pyssp_vv`; this package wraps it.

## Rationale

`@node` is a policy annotation, not a behavioural wrapper: called directly it
runs inline. The real constraints it imposes are picklability, cancellation,
and abort containment. Keeping nodes in one layer made the flow engine an
optional extra and kept its types from consumers who do not want it.

## Alternatives Considered

- Make every workflow function a node. Rejected: it makes the flow engine
  mandatory and leaks its types to every consumer.

## Consequences

- Domain signatures never mention `sequence_extensions`.
- A node's contract is catalogued because flows are user code.
- Retries and timeouts are declared per node, where they are visible.
- Engine nodes run in a child process.
- Node granularity is the artifact boundary: coarser prevents parallelism and
  hides which artifact a step produces; finer produces trivial nodes.

## Verification

`tests/test_layering.py::test_flow_engine_is_confined_to_the_node_layer`.

## Review Trigger

A different orchestration engine, or an artifact boundary that no longer
matches node granularity.
