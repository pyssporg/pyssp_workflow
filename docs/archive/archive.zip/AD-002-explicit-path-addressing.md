---
id: AD-002
type: architecture-decision
title: Explicit Path Addressing
summary: "Every public function takes explicit input paths and an output directory; no working-directory convention."
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - src/pyssp_workflow/fixture.py
supersedes: []
superseded_by: []
related: []
---

# AD-002: Explicit Path Addressing

## Context

Consumers hold SSP models in their own layouts, and some flows consume
artifacts produced elsewhere. Nodes had to stay picklable for process pools.

## Decision

- Every public function and node takes explicit input paths and an explicit output directory.
- Outputs derive from the assessment identifier within the output directory, never from the process working directory.
- A convenience helper may compute conventional paths; it returns plain paths and data, holds no open handles, and is never required.
- Functions return absolute paths; manifests relativise them on write.

## Rationale

Project-root conventions made every function working-directory sensitive and
unusable for a consumer with a different layout. An injected resolver created
two code paths and two failure modes per call and weakened picklability.
Explicit paths make the artifact dependency graph visible at the call site.

## Alternatives Considered

- A project-root convention. Rejected: it ties every function to the working
  directory.
- An injected path resolver. Rejected: two code paths and two failure modes
  per call.

## Consequences

- Signatures are longer; paths are grouped into small frozen dataclasses
  rather than long positional lists.
- A node's output location is predictable from its arguments, so "one node
  owns one output path" is checkable.
- Callers choose directories; nodes create them.

## Verification

`tests/test_authoring_build.py::test_artifacts_root_defaults_to_repo_root_and_is_never_the_cwd`.

## Review Trigger

A consumer layout that explicit paths cannot express.
