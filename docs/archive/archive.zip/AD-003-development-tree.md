---
id: AD-003
type: architecture-decision
title: This Repository Owns the Development Tree
summary: "pyssp_workflow is the development tree; the five capabilities are gitlinks under 3rd_party/."
date: 2026-10-22
status: accepted
layers: [architecture, operation]
state: 05-operation/submodules.md
artifacts:
  - .gitmodules
  - pyproject.toml
  - requirements-dev.txt
  - requirements-flow.txt
  - requirements-sysml.txt
supersedes: []
superseded_by: []
related: []
---

# AD-003: This Repository Owns the Development Tree

## Context

The five capabilities were each linked as a submodule of `ssp_references`, so
development happened in a consumer repository. Every capability change needed
a gitlink commit there, and no single checkout could build and test the whole
composition. Only `pyssp-standard` was on PyPI; the rest were git-only, so the
development checkout remained the install mechanism.

## Decision

- `pyssp_workflow` became the development tree.
- The five capabilities are linked under `3rd_party/`; `ssp_references` links this repository only.
- `.gitmodules` pins the exact revision each capability was tested with; `pyssp_standard` stays detached on `alpha` and has no branch.
- Installation is split: `requirements-dev.txt` (standard, simulate, vv), `requirements-flow.txt` (Python 3.11+, flow engine), `requirements-sysml.txt` (CLI-only authoring).
- `pyproject.toml` keeps `build`, `simulate`, and `flow` as reserved names for the first PyPI release.
- Submodule URLs use HTTPS so `actions/checkout` fetches them without a deploy key; gitlinks, not branch tracking, define what CI runs.

## Rationale

A consumer-owned pin made capability work and consumer work inseparable. One
development tree gave a single checkout that builds and tests the whole
composition, while keeping each package separately versioned.

## Alternatives Considered

- Keep the flat layout in `ssp_references`. Rejected: the consumer owns the
  development pins.
- A monorepo with packages instead of submodules. Rejected for now: it
  discards per-repository tags and release workflows.
- Declare git URLs in `pyproject.toml`. Rejected: pip clones its own copies
  that diverge from the checked-out submodules.

## Consequences

- One clone produces the whole composition; `git submodule update --init
  --recursive` is the only setup step beyond `pip install -r`.
- Bumping a capability costs three commits: capability, this gitlink, then the
  consumer's gitlink.
- A `pyssp_vv`-only developer clones this repository or `pyssp_vv` directly;
  the pin here does not restrict the capability's own releases.
- Physical nesting does not change the import rules.
- CI checks out recursively and installs `requirements-dev.txt`.

## Verification

CI checks out recursive submodules and installs `requirements-dev.txt`;
without that the suite would test a package that cannot import its
capabilities.

## Review Trigger

A monorepo with packages instead of submodules, or a capability published to
PyPI.
