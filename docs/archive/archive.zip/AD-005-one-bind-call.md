---
id: AD-005
type: architecture-decision
title: One bind Call Instead of a Binding Record Union
summary: "Binding is one bind call with mode, mapping, and components axes; the Binding union is gone."
date: 2026-10-27
status: accepted
layers: [architecture, product]
state: 01-product/module-surface.md
artifacts:
  - src/pyssp_workflow/binding.py
supersedes: []
superseded_by: []
related: [AD-004]
---

# AD-005: One `bind` Call Instead of a Binding Record Union

## Context

`AD-004` gave `binding` a closed union of five records — `ExternalStudy`,
`InlineRoot`, `TargetNamedExternal`, `InlineComponents`, `InlineWithMapping` —
and `apply_bindings`, which branched on the record type. Each record encoded
one combination of three independent choices: where the parameter set lives
(external or inline), how it is keyed (SSV member names or SSP target names),
and whether it splits per component. A new combination required a new record
and branch, while callers chose a type instead of naming artifact, key space,
and placement.

## Decision

- Binding became one function: `bind(build, ssv, *, set_name=None, mode="external"|"inline", ssm=None, mapping="attach"|"flatten", components=None) -> BindingResult`.
- `ssv` is the only value input, read once and read-only; `ssm` is the optional, read-only mapping artifact.
- The explicit axes are `mode`, `mapping`, and `components`.
- `BindingResult` reports SSP, mode, mapping, parameter set, resource names, written component paths, and parameter count.
- Deleted the five records, the `Binding` union, and `apply_bindings`; `__all__` is `["BindingResult", "bind"]`.
- This superseded only the binding-union part of `AD-004`; its module layout, `BuiltFixture` ownership, and layering rules stood.

## Rationale

Call sites now name the artifact, the key space, and the placement directly.
The closed union forced a type per combination, so adding a variant changed
the public surface rather than extending an argument contract, and the type
name substituted for the three decisions it concealed. One function with
explicit keyword axes kept the surface small while the four placements stayed
separate internal helpers.

## Alternatives Considered

- Keep the union and add a record for each new combination. Rejected: records
  track the number of combinations.
- Expose one function per placement. Rejected: it moves the combination back
  into the call site's choice of function.
- Accept a configuration record with the axes as fields. Rejected: it adds a
  type with no behaviour.

## Consequences

- A new placement extends the `mode`/`mapping` contract or the `components`
  rule instead of adding a public record.
- Invalid combinations fail at call time: `components` with external mode,
  `components` with `attach`, and inline `attach` without `ssm` raise
  `ValueError`.
- `BindingResult` is plain data, so callers see which resources and component
  sets were written without re-reading the SSP.
- `binding` imports only `pyssp_standard` and `fixture`; `study` is no longer
  a dependency.
- Only `build.model_dir` is mutated; input SSV and SSM stay read-only.
- Value reading and mapping resolution are delegated to `pyssp_standard`.

## Verification

`tests/test_binding.py` covers the four placements, typed parameters, and
every rejected combination.

## Review Trigger

A placement that `mode`, `mapping`, and `components` cannot express.
